/*
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.pokescanner.events;

import com.pokescanner.objects.GoogleAuthToken;

/**
 * Created by Brian on 7/22/2016.
 */
public class AuthLoadedEvent {
    public static final int OK = 1;
    public static final int AUTH_FAILED = 2;
    public static final int SERVER_FAILED = 3;
    int status;
    GoogleAuthToken token;

    public AuthLoadedEvent(int status,GoogleAuthToken token) {
        this.status = status;
        this.token = token;
    }

    public AuthLoadedEvent(int status) {
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public GoogleAuthToken getToken() {
        return token;
    }

    public void setToken(GoogleAuthToken token) {
        this.token = token;
    }
}
