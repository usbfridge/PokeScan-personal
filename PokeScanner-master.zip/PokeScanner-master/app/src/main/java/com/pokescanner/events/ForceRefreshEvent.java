package com.pokescanner.events;

/**
 * Created by Brian on 7/23/2016.
 */
public class ForceRefreshEvent {
}
