package com.pokescanner.events;

/**
 * Created by Brian on 7/25/2016.
 */
public class ForceLogoutEvent {
}
