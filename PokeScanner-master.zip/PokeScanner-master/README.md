# PokeScanner
A Scanning tool dedicated to helping you locate pokemon in your area. 

![Map](http://i.imgur.com/u8zPO1B.png)
![Map](http://i.imgur.com/7szBuM0.png)
![Map](http://i.imgur.com/aHofJAV.png)

# Instructions
- Download the APK
- Allow installations from Unknown sources
- Install the APK
- Enter your username and password (Warning:Do not use your main account information)
- Press Scan and where ever your camera is centered is where the application will scan


###[Download Section](https://github.com/BrianEstrada/PokeScanner/releases)

# Credits
- [Java Api](https://github.com/Grover-c13/PokeGOAPI-Java/)
- [Tsunamii](https://github.com/Tsunamii) (Material Icon)
- [rhari991](https://github.com/rhari991)
- [swhittaker](https://github.com/swhittaker)
- [toumeitou](https://github.com/toumeitou)
- [leTokki](https://github.com/leTokki)
- [ljk1291](https://github.com/ljk1291)
- [fizzxed](https://github.com/fizzxed)
- [EZTEQ](https://github.com/EZTEQ)

#Translators
- Thanya31 (Spanish)
- Chemi (Hebrew)
- Sébastien Bénazet(French)
- MrYadro (Russian)
- EZTEQ (German)
- tajchert (Polish)

# Contributions
Anyone is welcome to help out on the project just go ahead and submit any changes and I'll aprove em!


For discussion, Feature requeuest and just general information follow us at [/r/PokeScanner](https://www.reddit.com/r/PokeScanner)
